﻿internal interface IConnectionMultiplexer
{
}