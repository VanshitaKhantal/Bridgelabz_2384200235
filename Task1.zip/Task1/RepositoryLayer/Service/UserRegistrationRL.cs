﻿using ModelLayer.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ModelLayer.DTO;

namespace RepositoryLayer.Service
{
    public class UserRegistrationRL
    {
        private string databaseEmail = "Vanshita@gmail.com";
        private string databasePassword = "123456";
        public UserRegistrationRL() 
        {
        }

        public string registrationRL(string name)
        {
            return name + " Hello from Repository Layer" ;
        }

        public RegisterDTO GetUserByEmail(string Email)
        {
            if (Email == databaseEmail)
            {
                return new RegisterDTO
                {
                    FirstName = "Vanshita",
                    LastName = "Khantal",
                    Email = databaseEmail,
                    Password = databasePassword
                };
            }
            return null;
        }

        public bool RegisterUser(RegisterDTO user)
        {
            if (user.Email == databaseEmail)
            {
                return false; 
            }

            databaseEmail = user.Email;
            databasePassword = user.Password;
            return true;
        }
    }
}
